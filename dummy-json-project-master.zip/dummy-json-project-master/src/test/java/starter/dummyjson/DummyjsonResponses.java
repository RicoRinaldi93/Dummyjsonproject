package starter.dummyjson;

public class DummyjsonResponses {
    public static String USER_ID = "user.id";
    public static String ID = "id";
    public static String USERNAME = "user.username";
    public static String ERRORMESSAGE = "message";
    public static String COMMENTS_ID = "'comments'[0].'id'";
    public static String BODY = "body";
    public static String POST_ID = "postId";
    public static String FIRST_NAME = "firstName";
    public static String LAST_NAME = "lastName";
    public static String TITLE = "title";
    public static String STOCK = "stock";
    public static String PRICE = "price";

}
